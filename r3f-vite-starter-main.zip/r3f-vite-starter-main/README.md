# r3f-vite-starter
A boilerplate to build R3F projects

```
yarn
yarn dev
```


![image](https://user-images.githubusercontent.com/6551176/221732091-23ee52cb-4150-42fa-b998-43628d7a6b0d.png)
